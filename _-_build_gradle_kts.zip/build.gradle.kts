// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.androidApplication) apply false
    alias(libs.plugins.kotlinAndroid) apply false
    alias(libs.plugins.kotlinJvm) apply false
    alias(libs.plugins.hiltAndroid) apply false
}

buildscript {
    repositories {
        google()
        mavenCentral()
        // For ffmpeg-kit
        maven { url = uri("https://jitpack.io") }
    }
}