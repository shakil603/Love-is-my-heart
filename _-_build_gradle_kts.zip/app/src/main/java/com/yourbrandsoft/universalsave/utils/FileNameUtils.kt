package com.yourbrandsoft.universalsave.utils

object FileNameUtils {
    /**
     * Sanitizes a string to be used as a file name, removing invalid characters.
     */
    fun sanitizeFileName(name: String): String {
        return name.replace("[^a-zA-Z0-9-_.]".toRegex(), "_")
            .replace("_{2,}".toRegex(), "_") // Replace multiple underscores with a single one
            .trim('_') // Remove leading/trailing underscores
            .take(200) // Limit length to prevent issues
    }
}