package com.yourbrandsoft.universalsave.utils

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import timber.log.Timber
import java.io.File
import java.io.FileInputStream

object MediaStoreUtils {

    /**
     * Adds a video file to the MediaStore, making it visible in galleries and file managers.
     * For Android 10 (API 29) and above, it moves the file to a public directory.
     * For older versions, it just scans the file.
     *
     * @param context The application context.
     * @param videoFile The file to add.
     * @param subDirectory The subdirectory within the public Downloads folder (e.g., "UniversalSave/Videos").
     * @return The Uri of the added file in MediaStore, or null if failed.
     */
    fun addVideoToMediaStore(context: Context, videoFile: File, subDirectory: String): Uri? {
        val mimeType = "video/mp4"
        val fileName = videoFile.name

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$subDirectory")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = context.contentResolver.insert(collection, values)

            uri?.let {
                try {
                    context.contentResolver.openOutputStream(it).use { outputStream ->
                        FileInputStream(videoFile).use { inputStream ->
                            inputStream.copyTo(outputStream!!)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    context.contentResolver.update(it, values, null, null)
                    Timber.d("Video added to MediaStore: $it")
                    return it
                } catch (e: Exception) {
                    Timber.e(e, "Failed to add video to MediaStore: $fileName")
                    context.contentResolver.delete(it, null, null)
                    return null
                }
            } ?: run {
                Timber.e("Failed to create new MediaStore entry for video: $fileName")
                return null
            }
        } else {
            // For older Android versions, just scan the file to make it visible
            MediaScannerConnection.scanFile(context, arrayOf(videoFile.absolutePath), arrayOf(mimeType), null)
            Timber.d("Video scanned for MediaStore: ${videoFile.absolutePath}")
            return Uri.fromFile(videoFile) // Return file Uri for older versions
        }
    }

    /**
     * Adds an audio file to the MediaStore, making it visible in music players and file managers.
     * For Android 10 (API 29) and above, it moves the file to a public directory.
     * For older versions, it just scans the file.
     *
     * @param context The application context.
     * @param audioFile The file to add.
     * @param subDirectory The subdirectory within the public Downloads folder (e.g., "UniversalSave/Audios").
     * @return The Uri of the added file in MediaStore, or null if failed.
     */
    fun addAudioToMediaStore(context: Context, audioFile: File, subDirectory: String): Uri? {
        val mimeType = "audio/mpeg" // Assuming MP3
        val fileName = audioFile.name

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/$subDirectory")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = context.contentResolver.insert(collection, values)

            uri?.let {
                try {
                    context.contentResolver.openOutputStream(it).use { outputStream ->
                        FileInputStream(audioFile).use { inputStream ->
                            inputStream.copyTo(outputStream!!)
                        }
                    }
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    context.contentResolver.update(it, values, null, null)
                    Timber.d("Audio added to MediaStore: $it")
                    return it
                } catch (e: Exception) {
                    Timber.e(e, "Failed to add audio to MediaStore: $fileName")
                    context.contentResolver.delete(it, null, null)
                    return null
                }
            } ?: run {
                Timber.e("Failed to create new MediaStore entry for audio: $fileName")
                return null
            }
        } else {
            // For older Android versions, just scan the file to make it visible
            MediaScannerConnection.scanFile(context, arrayOf(audioFile.absolutePath), arrayOf(mimeType), null)
            Timber.d("Audio scanned for MediaStore: ${audioFile.absolutePath}")
            return Uri.fromFile(audioFile) // Return file Uri for older versions
        }
    }
}