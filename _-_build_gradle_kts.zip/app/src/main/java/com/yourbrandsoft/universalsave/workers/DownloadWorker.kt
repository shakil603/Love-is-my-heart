package com.yourbrandsoft.universalsave.workers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.yourbrandsoft.universalsave.Constants
import com.yourbrandsoft.universalsave.Constants.DownloadType
import com.yourbrandsoft.universalsave.R
import com.yourbrandsoft.universalsave.data.repository.IAudioConverter
import com.yourbrandsoft.universalsave.data.repository.IVideoDownloader
import com.yourbrandsoft.universalsave.data.repository.Result
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import timber.log.Timber
import java.io.File

@HiltWorker
class DownloadWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted private val workerParams: WorkerParameters,
    private val videoDownloader: IVideoDownloader,
    private val audioConverter: IAudioConverter
) : CoroutineWorker(context, workerParams) {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    override suspend fun doWork(): Result {
        val url = inputData.getString(Constants.KEY_URL)
        val fileName = inputData.getString(Constants.KEY_FILE_NAME)
        val downloadType = inputData.getString(Constants.KEY_DOWNLOAD_TYPE)
            ?.let { DownloadType.valueOf(it) }

        if (url.isNullOrBlank() || fileName.isNullOrBlank() || downloadType == null) {
            return Result.failure(
                workDataOf(Constants.KEY_ERROR_MESSAGE to "Invalid input data for download.")
            )
        }

        createNotificationChannel()
        setForeground(createForegroundInfo(0, "Starting download for $fileName"))

        return try {
            when (downloadType) {
                DownloadType.VIDEO -> handleVideoDownload(url, fileName)
                DownloadType.AUDIO -> handleAudioDownload(url, fileName)
                DownloadType.CONVERTED_AUDIO -> handleConvertAndDownloadAudio(url, fileName)
            }
        } catch (e: Exception) {
            Timber.e(e, "DownloadWorker failed for URL: $url, Type: $downloadType")
            Result.failure(
                workDataOf(Constants.KEY_ERROR_MESSAGE to (e.message ?: "Unknown error"))
            )
        }
    }

    private suspend fun handleVideoDownload(url: String, fileName: String): Result {
        val outputDir = Constants.DOWNLOAD_DIR_VIDEOS
        return videoDownloader.downloadVideo(url, outputDir, fileName).collectAndReturnResult(
            onProgress = { progress ->
                setForeground(createForegroundInfo(progress, "Downloading video: $fileName ($progress%)"))
            },
            onSuccess = { filePath ->
                Timber.d("Video downloaded successfully: $filePath")
                Result.success(workDataOf(Constants.KEY_FILE_PATH to filePath))
            },
            onError = { errorMessage ->
                Timber.e("Video download failed: $errorMessage")
                Result.failure(workDataOf(Constants.KEY_ERROR_MESSAGE to errorMessage))
            }
        )
    }

    private suspend fun handleAudioDownload(url: String, fileName: String): Result {
        val outputDir = Constants.DOWNLOAD_DIR_AUDIOS
        return videoDownloader.downloadAudio(url, outputDir, fileName).collectAndReturnResult(
            onProgress = { progress ->
                setForeground(createForegroundInfo(progress, "Downloading audio: $fileName ($progress%)"))
            },
            onSuccess = { filePath ->
                Timber.d("Audio downloaded successfully: $filePath")
                Result.success(workDataOf(Constants.KEY_FILE_PATH to filePath))
            },
            onError = { errorMessage ->
                Timber.e("Audio download failed: $errorMessage")
                Result.failure(workDataOf(Constants.KEY_ERROR_MESSAGE to errorMessage))
            }
        )
    }

    private suspend fun handleConvertAndDownloadAudio(url: String, fileName: String): Result {
        val tempVideoFileName = "temp_${fileName}"
        val tempVideoFileDir = context.getExternalFilesDir(null)?.absolutePath + File.separator + "temp"
        val tempVideoFile = File(tempVideoFileDir, "$tempVideoFileName.mp4")

        // 1. Download video to a temporary file
        val videoDownloadResult = videoDownloader.downloadVideo(url, "temp", tempVideoFileName).first { it !is Result.Loading }

        val tempVideoFilePath = when (videoDownloadResult) {
            is Result.Success -> videoDownloadResult.data.second
            is Result.Error -> {
                Timber.e("Failed to download temp video for conversion: ${videoDownloadResult.message}")
                return Result.failure(workDataOf(Constants.KEY_ERROR_MESSAGE to "Failed to download video for conversion: ${videoDownloadResult.message}"))
            }
            is Result.Loading -> null // Should not happen with .first { !is Loading }
        }

        if (tempVideoFilePath.isNullOrBlank()) {
            return Result.failure(workDataOf(Constants.KEY_ERROR_MESSAGE to "Temporary video file path is null or blank."))
        }

        // yt-dlp-android saves to app-specific storage first, then moves to MediaStore.
        // We need the app-specific path for ffmpeg-kit.
        // Reconstruct the app-specific path from the tempVideoFileName and "temp" directory.
        val actualTempVideoFile = File(context.getExternalFilesDir(null), "temp/$tempVideoFileName.mp4")
        if (!actualTempVideoFile.exists()) {
            Timber.e("Actual temporary video file not found at: ${actualTempVideoFile.absolutePath}")
            return Result.failure(workDataOf(Constants.KEY_ERROR_MESSAGE to "Temporary video file not found for conversion."))
        }

        // 2. Convert the temporary video to audio
        val outputDir = Constants.DOWNLOAD_DIR_AUDIOS
        val audioConversionResult = audioConverter.convertVideoToAudio(actualTempVideoFile, outputDir, fileName).collectAndReturnResult(
            onProgress = { progress ->
                setForeground(createForegroundInfo(progress, "Converting video to audio: $fileName ($progress%)"))
            },
            onSuccess = { filePath ->
                Timber.d("Video to audio conversion successful: $filePath")
                Result.success(workDataOf(Constants.KEY_FILE_PATH to filePath))
            },
            onError = { errorMessage ->
                Timber.e("Video to audio conversion failed: $errorMessage")
                Result.failure(workDataOf(Constants.KEY_ERROR_MESSAGE to errorMessage))
            }
        )

        // 3. Clean up temporary video file
        if (actualTempVideoFile.exists()) {
            actualTempVideoFile.delete()
            Timber.d("Deleted temporary video file: ${actualTempVideoFile.absolutePath}")
        }

        return audioConversionResult
    }

    private suspend fun <T> Flow<com.yourbrandsoft.universalsave.data.repository.Result<Pair<Int, T?>>>.collectAndReturnResult(
        onProgress: suspend (Int) -> Unit,
        onSuccess: suspend (T?) -> Result,
        onError: suspend (String) -> Result
    ): Result {
        var finalResult: Result = Result.failure()
        collect { result ->
            when (result) {
                is com.yourbrandsoft.universalsave.data.repository.Result.Loading -> {
                    result.data?.first?.let { progress ->
                        onProgress(progress)
                    }
                }
                is com.yourbrandsoft.universalsave.data.repository.Result.Success -> {
                    finalResult = onSuccess(result.data.second)
                }
                is com.yourbrandsoft.universalsave.data.repository.Result.Error -> {
                    finalResult = onError(result.message)
                }
            }
        }
        return finalResult
    }

    private fun createForegroundInfo(progress: Int, message: String): ForegroundInfo {
        val notification = NotificationCompat.Builder(context, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(context.getString(R.string.app_name))
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_download) // Ensure you have this drawable
            .setProgress(100, progress, false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
        return ForegroundInfo(Constants.NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                Constants.NOTIFICATION_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifications for Universal Save downloads"
            }
            notificationManager.createNotificationChannel(channel)
        }
    }
}