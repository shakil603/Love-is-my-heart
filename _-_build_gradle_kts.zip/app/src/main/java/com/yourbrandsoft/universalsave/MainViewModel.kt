package com.yourbrandsoft.universalsave

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.yourbrandsoft.universalsave.Constants.DownloadType
import com.yourbrandsoft.universalsave.data.repository.IVideoDownloader
import com.yourbrandsoft.universalsave.data.repository.Result
import com.yourbrandsoft.universalsave.workers.DownloadWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val workManager: WorkManager,
    private val videoDownloader: IVideoDownloader // Used for initial video info fetching
) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        // Observe WorkManager work info
        workManager.getWorkInfosByTagLiveData(Constants.WORK_NAME_DOWNLOAD_VIDEO)
            .observeForever { workInfos -> handleWorkInfo(workInfos) }
        workManager.getWorkInfosByTagLiveData(Constants.WORK_NAME_DOWNLOAD_AUDIO)
            .observeForever { workInfos -> handleWorkInfo(workInfos) }
        workManager.getWorkInfosByTagLiveData(Constants.WORK_NAME_CONVERT_AND_DOWNLOAD_AUDIO)
            .observeForever { workInfos -> handleWorkInfo(workInfos) }
    }

    private fun handleWorkInfo(workInfos: List<WorkInfo>) {
        if (workInfos.isEmpty()) return

        // We are only interested in the latest work for a given tag
        val latestWorkInfo = workInfos.maxByOrNull { it.generation } ?: return

        when (latestWorkInfo.state) {
            WorkInfo.State.RUNNING -> {
                val progress = latestWorkInfo.progress.getInt("progress", 0)
                _uiState.update {
                    it.copy(
                        isLoading = true,
                        statusMessage = "Downloading... $progress%",
                        downloadProgress = progress
                    )
                }
            }
            WorkInfo.State.SUCCEEDED -> {
                val filePath = latestWorkInfo.outputData.getString(Constants.KEY_FILE_PATH)
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        statusMessage = "Download complete!",
                        downloadProgress = 100,
                        downloadedFilePath = filePath,
                        toastMessage = "Download complete! Saved to: ${filePath ?: "public storage"}"
                    )
                }
            }
            WorkInfo.State.FAILED -> {
                val errorMessage = latestWorkInfo.outputData.getString(Constants.KEY_ERROR_MESSAGE)
                    ?: "Download failed due to an unknown error."
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        statusMessage = "Download failed: $errorMessage",
                        downloadProgress = 0,
                        toastMessage = errorMessage
                    )
                }
            }
            WorkInfo.State.CANCELLED -> {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        statusMessage = "Download cancelled.",
                        downloadProgress = 0,
                        toastMessage = "Download cancelled."
                    )
                }
            }
            else -> {
                // ENQUEUED, BLOCKED
                _uiState.update {
                    it.copy(
                        isLoading = true,
                        statusMessage = "Queued for download...",
                        downloadProgress = 0
                    )
                }
            }
        }
    }

    fun onUrlChange(newUrl: String) {
        _uiState.update { it.copy(url = newUrl, isDownloadEnabled = newUrl.isNotBlank()) }
        if (newUrl.isNotBlank()) {
            fetchVideoInfo(newUrl)
        } else {
            _uiState.update { it.copy(videoTitle = null, playingVideoUrl = null) }
        }
    }

    private fun fetchVideoInfo(url: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(statusMessage = "Fetching video info...", isLoading = true) }
            videoDownloader.fetchVideoInfo(url).collect { result ->
                when (result) {
                    is Result.Success -> {
                        _uiState.update {
                            it.copy(
                                videoTitle = result.data.title,
                                statusMessage = "Ready to play/download: ${result.data.title}",
                                isLoading = false,
                                playingVideoUrl = result.data.directUrl // Use direct URL for playback if available
                            )
                        }
                    }
                    is Result.Error -> {
                        _uiState.update {
                            it.copy(
                                statusMessage = "Error fetching info: ${result.message}",
                                isLoading = false,
                                videoTitle = null,
                                playingVideoUrl = null,
                                toastMessage = "Error fetching video info: ${result.message}"
                            )
                        }
                    }
                    is Result.Loading -> {
                        _uiState.update { it.copy(statusMessage = "Fetching video info...", isLoading = true) }
                    }
                }
            }
        }
    }

    fun onPlayClick() {
        _uiState.update { it.copy(playingVideoUrl = uiState.value.url) } // Attempt to play the raw URL
        _uiState.update { it.copy(statusMessage = "Attempting to play video...") }
    }

    fun onDownloadVideoClick() {
        val url = _uiState.value.url
        val fileName = _uiState.value.videoTitle ?: "video_${System.currentTimeMillis()}"
        enqueueDownload(url, fileName, DownloadType.VIDEO, Constants.WORK_NAME_DOWNLOAD_VIDEO)
    }

    fun onDownloadAudioClick() {
        val url = _uiState.value.url
        val fileName = _uiState.value.videoTitle ?: "audio_${System.currentTimeMillis()}"
        enqueueDownload(url, fileName, DownloadType.AUDIO, Constants.WORK_NAME_DOWNLOAD_AUDIO)
    }

    fun onConvertAndDownloadAudioClick() {
        val url = _uiState.value.url
        val fileName = _uiState.value.videoTitle ?: "converted_audio_${System.currentTimeMillis()}"
        enqueueDownload(url, fileName, DownloadType.CONVERTED_AUDIO, Constants.WORK_NAME_CONVERT_AND_DOWNLOAD_AUDIO)
    }

    private fun enqueueDownload(url: String, fileName: String, type: DownloadType, tag: String) {
        _uiState.update {
            it.copy(
                isLoading = true,
                statusMessage = "Starting $type download...",
                downloadProgress = 0,
                downloadedFilePath = null
            )
        }

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val downloadRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(
                workDataOf(
                    Constants.KEY_URL to url,
                    Constants.KEY_FILE_NAME to fileName,
                    Constants.KEY_DOWNLOAD_TYPE to type.name
                )
            )
            .setConstraints(constraints)
            .addTag(tag)
            .build()

        workManager.enqueue(downloadRequest)
        Timber.d("Enqueued WorkManager request for $type: $url")
    }

    fun clearToastMessage() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}

data class MainUiState(
    val url: String = "",
    val videoTitle: String? = null,
    val isLoading: Boolean = false,
    val statusMessage: String = "Enter a video URL to start.",
    val downloadProgress: Int = 0,
    val isDownloadEnabled: Boolean = false,
    val playingVideoUrl: String? = null,
    val downloadedFilePath: String? = null,
    val toastMessage: String? = null
)