package com.yourbrandsoft.universalsave.data.repository

import com.yourbrandsoft.universalsave.data.model.VideoInfo
import kotlinx.coroutines.flow.Flow

interface IVideoDownloader {
    /**
     * Fetches video information from the given URL.
     * @param url The URL of the video.
     * @return A Flow emitting VideoInfo or an error.
     */
    fun fetchVideoInfo(url: String): Flow<Result<VideoInfo>>

    /**
     * Downloads the video from the given URL.
     * @param url The URL of the video.
     * @param outputDir The directory to save the video.
     * @param fileName The desired file name (without extension).
     * @return A Flow emitting download progress (0-100) and then the file path on completion.
     */
    fun downloadVideo(url: String, outputDir: String, fileName: String): Flow<Result<Pair<Int, String?>>> // Pair: progress, filePath

    /**
     * Downloads the audio from the given URL.
     * @param url The URL of the video.
     * @param outputDir The directory to save the audio.
     * @param fileName The desired file name (without extension).
     * @return A Flow emitting download progress (0-100) and then the file path on completion.
     */
    fun downloadAudio(url: String, outputDir: String, fileName: String): Flow<Result<Pair<Int, String?>>> // Pair: progress, filePath
}