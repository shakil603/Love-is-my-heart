package com.yourbrandsoft.universalsave.data.repository

import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import com.yourbrandsoft.universalsave.Constants
import com.yourbrandsoft.universalsave.utils.FileNameUtils
import com.yourbrandsoft.universalsave.utils.MediaStoreUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import timber.log.Timber
import java.io.File
import javax.inject.Inject

class FFmpegAudioConverter @Inject constructor(
    private val context: Context
) : IAudioConverter {

    override fun convertVideoToAudio(
        videoFile: File,
        outputDir: String,
        outputFileName: String
    ): Flow<Result<Pair<Int, String?>>> = flow {
        emit(Result.Loading(Pair(0, null)))
        try {
            if (!videoFile.exists()) {
                emit(Result.Error("Input video file does not exist: ${videoFile.absolutePath}"))
                return@flow
            }

            val sanitizedFileName = FileNameUtils.sanitizeFileName(outputFileName)
            val outputAudioFileName = "$sanitizedFileName.mp3"

            val downloadDir = File(context.getExternalFilesDir(null), outputDir)
            if (!downloadDir.exists()) {
                downloadDir.mkdirs()
            }
            val outputAudioFile = File(downloadDir, outputAudioFileName)

            // FFmpeg command to convert video to MP3
            // -i: input file
            // -vn: no video
            // -ab 128k: audio bitrate
            // -ar 44100: audio sample rate
            // -f mp3: force mp3 format
            val command = "-i \"${videoFile.absolutePath}\" -vn -ab 128k -ar 44100 -f mp3 \"${outputAudioFile.absolutePath}\""

            var session: FFmpegSession? = null
            session = FFmpegKit.executeAsync(command, { ffmpegSession ->
                val returnCode = ffmpegSession.returnCode
                if (ReturnCode.isSuccess(returnCode)) {
                    Timber.d("Video to audio conversion successful: ${outputAudioFile.absolutePath}")
                    // This success is handled by the flow's try-catch block after execution.
                } else if (ReturnCode.isCancel(returnCode)) {
                    Timber.w("Video to audio conversion cancelled.")
                    // This cancellation is also handled by the flow's try-catch block.
                } else {
                    Timber.e("Video to audio conversion failed with code: $returnCode. Error: ${ffmpegSession.failStackTrace}")
                    // This error is also handled by the flow's try-catch block.
                }
            }, { log ->
                // You can parse log messages to estimate progress if needed
                // For simplicity, we'll just emit 50% during conversion and 100% on completion.
                Timber.d("FFmpeg Log: ${log.message}")
                emit(Result.Loading(Pair(50, null))) // Emit a generic progress during conversion
            }, { statistics ->
                // Statistics can provide more accurate progress
                // statistics.time is in microseconds
                val totalDuration = statistics.time // This is not total duration, but current time processed
                // Estimating total duration from video info would be better, but for simplicity,
                // we'll use a fixed progress or rely on completion.
            })

            // Wait for the session to complete
            session?.await()

            if (session != null && ReturnCode.isSuccess(session.returnCode)) {
                if (outputAudioFile.exists() && outputAudioFile.length() > 0) {
                    // Add to MediaStore for visibility in gallery/file managers
                    val publicUri = MediaStoreUtils.addAudioToMediaStore(context, outputAudioFile, Constants.DOWNLOAD_DIR_AUDIOS)
                    outputAudioFile.delete() // Delete the app-specific file after moving to public storage
                    emit(Result.Success(Pair(100, publicUri?.toString())))
                } else {
                    emit(Result.Error("Audio conversion failed or output file is empty."))
                }
            } else {
                val errorMessage = session?.failStackTrace ?: "Unknown FFmpeg conversion error."
                emit(Result.Error("Audio conversion failed: $errorMessage"))
            }

        } catch (e: Exception) {
            Timber.e(e, "Error converting video to audio for file: ${videoFile.absolutePath}")
            emit(Result.Error("Error converting video to audio: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)
}