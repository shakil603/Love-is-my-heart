package com.yourbrandsoft.universalsave.di

import android.content.Context
import androidx.work.WorkManager
import com.yourbrandsoft.universalsave.data.repository.AudioConverter
import com.yourbrandsoft.universalsave.data.repository.IAudioConverter
import com.yourbrandsoft.universalsave.data.repository.IVideoDownloader
import com.yourbrandsoft.universalsave.data.repository.YtDlpVideoDownloader
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideWorkManager(@ApplicationContext context: Context): WorkManager {
        return WorkManager.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideVideoDownloader(@ApplicationContext context: Context): IVideoDownloader {
        return YtDlpVideoDownloader(context)
    }

    @Provides
    @Singleton
    fun provideAudioConverter(@ApplicationContext context: Context): IAudioConverter {
        return FFmpegAudioConverter(context)
    }
}