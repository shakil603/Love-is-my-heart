package com.yourbrandsoft.universalsave

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import io.reactivex.rxjava3.plugins.RxJavaPlugins
import timber.log.Timber
import java.io.File

@HiltAndroidApp
class UniversalSaveApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize Timber for logging
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        // Initialize yt-dlp-android
        // This might take some time, consider running in a background thread or showing a splash screen.
        Thread {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                // Optionally update yt-dlp and ffmpeg binaries
                // YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                // FFmpeg.getInstance().init(applicationContext) // ffmpeg-kit handles its own initialization
                Timber.d("yt-dlp-android initialized successfully.")
            } catch (e: YoutubeDLException) {
                Timber.e(e, "Failed to initialize yt-dlp-android")
            } catch (e: InterruptedException) {
                Timber.e(e, "yt-dlp-android initialization interrupted")
            }
        }.start()

        // RxJava error handler to prevent crashes from unhandled exceptions in Rx chains
        RxJavaPlugins.setErrorHandler { throwable ->
            Timber.e(throwable, "Unhandled RxJava Error")
            // You might want to log this to a crash reporting tool
        }
    }
}