package com.yourbrandsoft.universalsave

import android.os.Environment

object Constants {
    const val NOTIFICATION_CHANNEL_ID = "universal_save_channel"
    const val NOTIFICATION_CHANNEL_NAME = "Universal Save Downloads"
    const val NOTIFICATION_ID = 1001

    // WorkManager unique work names
    const val WORK_NAME_DOWNLOAD_VIDEO = "download_video_work"
    const val WORK_NAME_DOWNLOAD_AUDIO = "download_audio_work"
    const val WORK_NAME_CONVERT_AND_DOWNLOAD_AUDIO = "convert_and_download_audio_work"

    // WorkManager input/output keys
    const val KEY_URL = "url"
    const val KEY_FILE_PATH = "file_path"
    const val KEY_FILE_NAME = "file_name"
    const val KEY_DOWNLOAD_TYPE = "download_type"
    const val KEY_ERROR_MESSAGE = "error_message"

    // Download types
    enum class DownloadType {
        VIDEO, AUDIO, CONVERTED_AUDIO
    }

    // Default download directory names within app's external files dir
    const val DOWNLOAD_DIR_VIDEOS = "UniversalSave/Videos"
    const val DOWNLOAD_DIR_AUDIOS = "UniversalSave/Audios"

    // Public Downloads directory (for MediaStore)
    val PUBLIC_DOWNLOADS_DIR = Environment.DIRECTORY_DOWNLOADS
}