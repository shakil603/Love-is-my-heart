package com.yourbrandsoft.universalsave.data.repository

import kotlinx.coroutines.flow.Flow
import java.io.File

interface IAudioConverter {
    /**
     * Converts a video file to an audio file (e.g., MP3).
     * @param videoFile The input video file.
     * @param outputDir The directory to save the converted audio.
     * @param outputFileName The desired output file name (without extension).
     * @return A Flow emitting conversion progress (0-100) and then the file path on completion.
     */
    fun convertVideoToAudio(videoFile: File, outputDir: String, outputFileName: String): Flow<Result<Pair<Int, String?>>>
}