package com.yourbrandsoft.universalsave.data.model

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName

data class VideoInfo(
    @SerializedName("id") val id: String,
    @SerializedName("title") val title: String,
    @SerializedName("thumbnail") val thumbnail: String?,
    @SerializedName("duration") val duration: Long?, // in seconds
    @SerializedName("uploader") val uploader: String?,
    @SerializedName("webpage_url") val webpageUrl: String?,
    @SerializedName("url") val directUrl: String? // Direct URL to the stream (might not always be present or stable)
) {
    companion object {
        fun fromJson(jsonString: String): VideoInfo {
            return Gson().fromJson(jsonString, VideoInfo::class.java)
        }
    }
}