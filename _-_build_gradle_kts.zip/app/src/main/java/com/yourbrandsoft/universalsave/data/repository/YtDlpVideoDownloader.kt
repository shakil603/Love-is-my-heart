package com.yourbrandsoft.universalsave.data.repository

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.yourbrandsoft.universalsave.Constants
import com.yourbrandsoft.universalsave.data.model.VideoInfo
import com.yourbrandsoft.universalsave.utils.FileNameUtils
import com.yourbrandsoft.universalsave.utils.MediaStoreUtils
import com.yausername.youtubedl_android.DownloadProgressCallback
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File
import javax.inject.Inject

class YtDlpVideoDownloader @Inject constructor(
    private val context: Context
) : IVideoDownloader {

    override fun fetchVideoInfo(url: String): Flow<Result<VideoInfo>> = flow {
        emit(Result.Loading())
        try {
            val request = YoutubeDLRequest(url)
            val format = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" // Prioritize mp4
            request.addOption("--format", format)
            request.addOption("--dump-json")
            request.addOption("--no-simulate") // Ensure it fetches actual info, not just simulates

            val youtubeDLResponse = YoutubeDL.getInstance().execute(request)

            if (youtubeDLResponse.exitCode == 0) {
                val json = youtubeDLResponse.out
                val videoInfo = VideoInfo.fromJson(json)
                emit(Result.Success(videoInfo))
            } else {
                emit(Result.Error("Failed to fetch video info: ${youtubeDLResponse.err}"))
            }
        } catch (e: Exception) {
            Timber.e(e, "Error fetching video info for URL: $url")
            emit(Result.Error("Error fetching video info: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)

    override fun downloadVideo(
        url: String,
        outputDir: String,
        fileName: String
    ): Flow<Result<Pair<Int, String?>>> = flow {
        emit(Result.Loading(Pair(0, null)))
        try {
            val sanitizedFileName = FileNameUtils.sanitizeFileName(fileName)
            val outputFileName = "$sanitizedFileName.mp4"

            val downloadDir = File(context.getExternalFilesDir(null), outputDir)
            if (!downloadDir.exists()) {
                downloadDir.mkdirs()
            }
            val outputFile = File(downloadDir, outputFileName)

            val request = YoutubeDLRequest(url)
            request.addOption("--output", outputFile.absolutePath)
            request.addOption("--format", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best") // Prioritize mp4
            request.addOption("--embed-metadata") // Embed metadata if available

            YoutubeDL.getInstance().execute(request, object : DownloadProgressCallback {
                override fun onProgressUpdate(
                    progress: Float,
                    eta: Long,
                    speed: String?,
                    remainingBytes: Long
                ) {
                    emit(Result.Loading(Pair(progress.toInt(), null)))
                }
            })

            if (outputFile.exists() && outputFile.length() > 0) {
                // Add to MediaStore for visibility in gallery/file managers
                val publicUri = MediaStoreUtils.addVideoToMediaStore(context, outputFile, Constants.DOWNLOAD_DIR_VIDEOS)
                outputFile.delete() // Delete the app-specific file after moving to public storage
                emit(Result.Success(Pair(100, publicUri?.toString())))
            } else {
                emit(Result.Error("Video download failed or file is empty."))
            }
        } catch (e: Exception) {
            Timber.e(e, "Error downloading video for URL: $url")
            emit(Result.Error("Error downloading video: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)

    override fun downloadAudio(
        url: String,
        outputDir: String,
        fileName: String
    ): Flow<Result<Pair<Int, String?>>> = flow {
        emit(Result.Loading(Pair(0, null)))
        try {
            val sanitizedFileName = FileNameUtils.sanitizeFileName(fileName)
            val outputFileName = "$sanitizedFileName.mp3"

            val downloadDir = File(context.getExternalFilesDir(null), outputDir)
            if (!downloadDir.exists()) {
                downloadDir.mkdirs()
            }
            val outputFile = File(downloadDir, outputFileName)

            val request = YoutubeDLRequest(url)
            request.addOption("--extract-audio")
            request.addOption("--audio-format", "mp3")
            request.addOption("--output", outputFile.absolutePath)
            request.addOption("--embed-metadata")

            YoutubeDL.getInstance().execute(request, object : DownloadProgressCallback {
                override fun onProgressUpdate(
                    progress: Float,
                    eta: Long,
                    speed: String?,
                    remainingBytes: Long
                ) {
                    emit(Result.Loading(Pair(progress.toInt(), null)))
                }
            })

            if (outputFile.exists() && outputFile.length() > 0) {
                // Add to MediaStore for visibility in gallery/file managers
                val publicUri = MediaStoreUtils.addAudioToMediaStore(context, outputFile, Constants.DOWNLOAD_DIR_AUDIOS)
                outputFile.delete() // Delete the app-specific file after moving to public storage
                emit(Result.Success(Pair(100, publicUri?.toString())))
            } else {
                emit(Result.Error("Audio download failed or file is empty."))
            }
        } catch (e: Exception) {
            Timber.e(e, "Error downloading audio for URL: $url")
            emit(Result.Error("Error downloading audio: ${e.message}"))
        }
    }.flowOn(Dispatchers.IO)
}