# ১. প্রজেক্ট-লেভেল build.gradle.kts

Automatically structured project package.

## 📁 Included Files:
- `build.gradle.kts`
- `app/build.gradle.kts`
- `gradle/libs.versions.toml`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/xml/file_paths.xml`
- `app/src/main/java/com/yourbrandsoft/universalsave/UniversalSaveApp.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/Constants.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/di/AppModule.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/data/repository/IVideoDownloader.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/data/repository/YtDlpVideoDownloader.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/data/repository/IAudioConverter.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/data/repository/FFmpegAudioConverter.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/data/model/VideoInfo.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/data/repository/Result.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/utils/FileNameUtils.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/utils/MediaStoreUtils.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/workers/DownloadWorker.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/MainActivity.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/MainViewModel.kt`
- `app/src/main/java/com/yourbrandsoft/universalsave/ui/components/ExoPlayerView.kt`
- `app/src/main/res/drawable/ic_download.xml`
- `.github/workflows/android_build.yml`
- `app/build/outputs/apk/debug/app-debug.apk`